<?php
include_once 'public/headerSections.php';
?>


<div class="container" style="margin-bottom: 100px">
    <h2 id="contactTitles"> Ponete en contacto con nosotros</h2>
    <div class="col">
        <div class="col">            
            <img  id="whatsapp" src="public/img/whatsapp.jpg" width="100" height="100" alt="Card image cap">
            <label for="whatsapp" class="contactLabels"> +506 7245 1637</label>          
        </div>      
        <div class="col">            
            <img  id="gmail" src="public/img/gmail.png" width="100" height="100" alt="Card image cap">
            <label for="gmail" class="contactLabels"> lacteosherencia@gmail.com</label>            
        </div>  
        <h4 id="contactTitles"> También podes encontrarnos en nuestras redes sociales</h4>
        <div class="col">
            <img  id="instagram" src="public/img/instagram.jpg" width="100" height="100" alt="Card image cap">
            <label for="instagram" class="contactLabels"> lacteos.herencia</label>
        </div>    
        <div class="col">
            <img  id="facebook" src="public/img/facebook.jpg" width="100" height="100" alt="Card image cap">
            <label for="facebook" class="contactLabels"> Lácteos Herencia</label>
        </div>  
    </div>
</div>



<?php
include_once 'public/footerSections.php';
?>
