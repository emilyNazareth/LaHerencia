<?php
include_once 'public/header.php';
?>
<div class="container">
    <div class="row">
        <div class="col-sm">
            <main role="main" class="inner cover">
                <h1 style="color: #B52222; margin-bottom: 2%;">Nuestra empresa</h1>
                <h4 style="color:  #004063;">Lácteos Herencia es una empresa familiar de lácteos artesanales con su origen en El Torito, Santa Cruz de Turrialba, Costa Rica. Productores de leche a base del ganado Jersey, garantizando un producto de alta calidad y sabor</h4>
                <a href="?controlador=Products&accion=showProducts" class="btn sample btn-lg active btn-sample">Ver Productos</a>
            </main>

        </div>
    </div>
</div>








<?php
include_once 'public/footer.php';
?>