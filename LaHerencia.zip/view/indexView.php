<?php
include_once 'public/header.php';
?>

<div class="container">
    <div class="row">
        <div class="col-sm">
            <a href="?controlador=Products&accion=showProducts" class="btn sample btn-lg active btn-sample">Nuestros Productos</a>
        </div>
    </div>    
</div>


<?php
include_once 'public/footer.php';
?>