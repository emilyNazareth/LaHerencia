<?php
include_once 'public/header.php';
?>
<div class="container">
    <div class="row">
        <div class="col-sm">
            <main role="main" class="inner cover">
                <h1 style="color: #B52222; margin-bottom: 5%;">Nuestra empresa</h1>
                <h4 class="font-weight-bold" style="color:  #004063;">Somos una compañía dedicada a ofrecer los alimentos favoritos de las comunidades</h4>
                <h4 class="font-weight-bold" style="color:  #004063;">Ofrecemos productos de calidad en diversos precios</h4>
                <a href="?controlador=Products&accion=showProducts" class="btn sample btn-lg active btn-sample">Ver Productos</a>
            </main>

        </div>
    </div>
</div>








<?php
include_once 'public/footer.php';
?>