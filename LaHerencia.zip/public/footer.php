</section>
</section>
</div>
<footer>
    <div id="footerSections">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-sm-12 col-md-12 col-lg-4" id="infoFooter">
                    <h5>Contáctenos</h5>
                    lacteosherencia@gmail.com
                    <p> Torito de Santa Cruz de Turrialba, Cartago.</p> <!-- eliminar los espacios -->
                    Telefono
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-lg-4">
                    <img id="imgLogoFooter" src="public/img/LogoHerenciaBlanco.png" alt="Lácteos Herencia" width="400"
                        height="200">
                </div><!-- redireccionarlo al inicio -->
                <div class="col-12 col-sm-12 col-md-12 col-lg-4 ">
                    <ul class="list-unstyled " id="iconosFooter">
                        <a href="https://www.facebook.com/lacteosherencia">
                            <img src="public/img/iconoface.png" style="margin-right: 25px" width="34" height="34" /></a>
                        <a href="https://wa.me/50672451637">
                            <img src="public/img/iconowhatsapp.png" style="margin-right: 25px" width="34"
                                height="34" /></a>
                        <a href="https://www.instagram.com/lacteos.herencia/">
                            <img src="public/img/instagram.png" style="margin-right: 25px" width="34" height="34" />
                        </a>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>


</body>