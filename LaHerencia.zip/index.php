<?php

    require 'libs/FrontController.php';
    FrontController::main();

?>

